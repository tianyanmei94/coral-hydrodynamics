clc
clear


data1um = load('1ABCDEF-um.mat');
data1V  = load('1ABCDEF-V[490-510].mat');
data1pm = load('1ABCDEF-pm.mat');                         
data1P  = load('1ABCDEF-P[490-510].mat');
data1W  = load('1ABCDEF-W.mat');
data1wm = load('1ABCDEF-wm.mat');
A1m = data1V.Am.*0.0733;
B1m = data1V.Bm.*0.0733;
C1m = data1V.Cm.*0.0733;
D1m = data1V.Dm.*0.0733;
E1m = data1V.Em.*0.0733;
F1m = data1V.Fm.*0.0733;
U1ABm   = A1m-B1m;
U1CDm   = C1m-D1m;
U1EFm   = E1m-F1m;

A1d = data1P.Aad.*5.373;
B1d = data1P.Bbd.*5.373;
C1d = data1P.Ccd.*5.373;
D1d = data1P.Ddd.*5.373;
E1d = data1P.Eed.*5.373;
F1d = data1P.Ffd.*5.373;
P1ABd   = A1d-B1d;
P1CDd   = C1d-D1d;
P1EFd   = E1d-F1d;

A1w = data1W.E_A.*0.802.*1e6;
B1w = data1W.E_B.*0.802.*1e6;
C1w = data1W.E_C.*0.802.*1e6;
D1w = data1W.E_D.*0.802.*1e6;
E1w = data1W.E_E.*0.802.*1e6;
F1w = data1W.E_F.*0.802.*1e6;
W1ABw   = A1w-B1w;
W1CDw   = C1w-D1w;
W1EFw   = E1w-F1w;

data9um = load('9ABCDEF-um.mat');
data9V  = load('9ABCDEF-V[490-510].mat');
data9pm = load('9ABCDEF-pm.mat');
data9P  = load('9ABCDEF-P[490-510].mat');
data9W  = load('9ABCDEF-W.mat');
data9wm = load('9ABCDEF-wm.mat');
A9m = data9V.Am.*0.0733;
B9m = data9V.Bm.*0.0733;
C9m = data9V.Cm.*0.0733;
D9m = data9V.Dm.*0.0733;
E9m = data9V.Em.*0.0733;
F9m = data9V.Fm.*0.0733;
U9ABm = A9m-B9m;
U9CDm = C9m-D9m;
U9EFm = E9m-F9m;

A9d = data9P.Aad.*5.373;
B9d = data9P.Bbd.*5.373;
C9d = data9P.Ccd.*5.373;
D9d = data9P.Ddd.*5.373;
E9d = data9P.Eed.*5.373;
F9d = data9P.Ffd.*5.373;
P9ABd   = A9d-B9d;
P9CDd   = C9d-D9d;
P9EFd   = E9d-F9d;

A9w = data9W.E_A.*0.802.*1e6;
B9w = data9W.E_B.*0.802.*1e6;
C9w = data9W.E_C.*0.802.*1e6;
D9w = data9W.E_D.*0.802.*1e6;
E9w = data9W.E_E.*0.802.*1e6;
F9w = data9W.E_F.*0.802.*1e6;
W9ABw   = A9w-B9w;
W9CDw   = C9w-D9w;
W9EFw   = E9w-F9w; 


data17um = load('17ABCDEF-um.mat');
data17V  = load('17ABCDEF-V[490-510].mat');
data17pm = load('17ABCDEF-pm.mat');
data17P  = load('17ABCDEF-P[490-510].mat');
data17W  = load('17ABCDEF-W.mat');
data17wm = load('17ABCDEF-wm.mat');
A17m = data17V.Am.*0.0733;
B17m = data17V.Bm.*0.0733;
C17m = data17V.Cm.*0.0733;
D17m = data17V.Dm.*0.0733;
E17m = data17V.Em.*0.0733;
F17m = data17V.Fm.*0.0733;
U17ABm = A17m-B17m;
U17CDm = C17m-D17m;
U17EFm = E17m-F17m;

A17d = data17P.Aad.*5.373;
B17d = data17P.Bbd.*5.373;
C17d = data17P.Ccd.*5.373;
D17d = data17P.Ddd.*5.373;
E17d = data17P.Eed.*5.373;
F17d = data17P.Ffd.*5.373;
P17ABd   = A17d-B17d;
P17CDd   = C17d-D17d;
P17EFd   = E17d-F17d;

A17w = data17W.E_A.*0.802.*1e6;
B17w = data17W.E_B.*0.802.*1e6;
C17w = data17W.E_C.*0.802.*1e6;
D17w = data17W.E_D.*0.802.*1e6;
E17w = data17W.E_E.*0.802.*1e6;
F17w = data17W.E_F.*0.802.*1e6;
W17ABw   = A17w-B17w;
W17CDw   = C17w-D17w;
W17EFw   = E17w-F17w;


data23um = load('23ABCDEF-um.mat');
data23V  = load('23ABCDEF-V[490-510].mat');
data23pm = load('23ABCDEF-pm.mat');
data23P  = load('23ABCDEF-P[490-510].mat');
data23W  = load('23ABCDEF-W.mat');
data23wm = load('23ABCDEF-wm.mat');
A23m = data23V.Am.*0.1222;
B23m = data23V.Bm.*0.1222;
C23m = data23V.Cm.*0.1222;
D23m = data23V.Dm.*0.1222;
E23m = data23V.Em.*0.1222;
F23m = data23V.Fm.*0.1222;
U23ABm = A23m-B23m;
U23CDm = C23m-D23m;
U23EFm = E23m-F23m;

A23d = data23P.Aad.*14.93;
B23d = data23P.Bbd.*14.93;
C23d = data23P.Ccd.*14.93;
D23d = data23P.Ddd.*14.93;
E23d = data23P.Eed.*14.93;
F23d = data23P.Ffd.*14.93;
P23ABd   = A23d-B23d;
P23CDd   = C23d-D23d;
P23EFd   = E23d-F23d;

A23w = data23W.E_A.*2.227.*1e6;
B23w = data23W.E_B.*2.227.*1e6;
C23w = data23W.E_C.*2.227.*1e6;
D23w = data23W.E_D.*2.227.*1e6;
E23w = data23W.E_E.*2.227.*1e6;
F23w = data23W.E_F.*2.227.*1e6;
W23ABw   = A23w-B23w;
W23CDw   = C23w-D23w;
W23EFw   = E23w-F23w;

data30um = load('30ABCDEF-um.mat');
data30V  = load('30ABCDEF-V[490-510].mat');
data30pm = load('30ABCDEF-pm.mat');
data30P  = load('30ABCDEF-P[490-510].mat');
data30W  = load('30ABCDEF-W.mat');
data30wm = load('30ABCDEF-wm.mat');
A30m = data30V.Am.*0.1466;
B30m = data30V.Bm.*0.1466;
C30m = data30V.Cm.*0.1466;
D30m = data30V.Dm.*0.1466;
E30m = data30V.Em.*0.1466;
F30m = data30V.Fm.*0.1466;
U30ABm = A30m-B30m;
U30CDm = C30m-D30m;
U30EFm = E30m-F30m;

A30d = data30P.Aad.*21.49;
B30d = data30P.Bbd.*21.49;
C30d = data30P.Ccd.*21.49;
D30d = data30P.Ddd.*21.49;
E30d = data30P.Eed.*21.49;
F30d = data30P.Ffd.*21.49;
P30ABd   = A30d-B30d;
P30CDd   = C30d-D30d;
P30EFd   = E30d-F30d;

A30w = data30W.E_A.*3.207.*1e6;
B30w = data30W.E_B.*3.207.*1e6;
C30w = data30W.E_C.*3.207.*1e6;
D30w = data30W.E_D.*3.207.*1e6;
E30w = data30W.E_E.*3.207.*1e6;
F30w = data30W.E_F.*3.207.*1e6;
W30ABw   = A30w-B30w;
W30CDw   = C30w-D30w;
W30EFw   = E30w-F30w;

data42um = load('42ABCDEF-um.mat');
data42V  = load('42ABCDEF-V[490-510].mat');
data42pm = load('42ABCDEF-pm.mat');
data42P  = load('42ABCDEF-P[490-510].mat');
data42W  = load('42ABCDEF-W.mat');
data42wm = load('42ABCDEF-wm.mat');
A42m = data42V.Am.*0.2199;
B42m = data42V.Bm.*0.2199;
C42m = data42V.Cm.*0.2199;
D42m = data42V.Dm.*0.2199;
E42m = data42V.Em.*0.2199;
F42m = data42V.Fm.*0.2199;
U42ABm = A42m-B42m;
U42CDm = C42m-D42m;
U42EFm = E42m-F42m;

A42d = data42P.Aad.*48.36;
B42d = data42P.Bbd.*48.36;
C42d = data42P.Ccd.*48.36;
D42d = data42P.Ddd.*48.36;
E42d = data42P.Eed.*48.36;
F42d = data42P.Ffd.*48.36;
P42ABd   = A42d-B42d;
P42CDd   = C42d-D42d;
P42EFd   = E42d-F42d;

A42w = data42W.E_A.*7.216.*1e6;
B42w = data42W.E_B.*7.216.*1e6;
C42w = data42W.E_C.*7.216.*1e6;
D42w = data42W.E_D.*7.216.*1e6;
E42w = data42W.E_E.*7.216.*1e6;
F42w = data42W.E_F.*7.216.*1e6;
W42ABw   = A42w-B42w;
W42CDw   = C42w-D42w;
W42EFw   = E42w-F42w;


U1m  = (U1ABm+U1CDm+U1EFm)/3;
U9m  = (U9ABm+U9CDm+U9EFm)/3;
U17m = (U17ABm+U17CDm+U17EFm)/3;
U23m = (U23ABm+U23CDm+U23EFm)/3;
U30m = (U30ABm+U30CDm+U30EFm)/3;
U42m = (U42ABm+U42CDm+U42EFm)/3;

P1m  = (P1ABd+P1CDd+P1EFd)/3;
P9m  = (P9ABd+P9CDd+P9EFd)/3;
P17m = (P17ABd+P17CDd+P17EFd)/3;
P23m = (P23ABd+P23CDd+P23EFd)/3;
P30m = (P30ABd+P30CDd+P30EFd)/3;
P42m = (P42ABd+P42CDd+P42EFd)/3;

W1m  = (W1ABw+W1CDw+W1EFw)/3;
W9m  = (W9ABw+W9CDw+W9EFw)/3;
W17m = (W17ABw+W17CDw+W17EFw)/3;
W23m = (W23ABw+W23CDw+W23EFw)/3;
W30m = (W30ABw+W30CDw+W30EFw)/3;
W42m = (W42ABw+W42CDw+W42EFw)/3;

subplot('position',[0.07,0.68 0.72 0.25])  % P『274-285』
x     = [1:1:21];
x     = x.';
plot(x,P1m,'-.','linewidth',1.5,'Color',[0.98 0.50 0.45])
hold on
plot(x,P9m,'-.','linewidth',1.5,'Color',[0.25 0.41 0.88])
plot(x,P17m,'-.','linewidth',1.5,'Color',[0.69 0.09 0.12])
plot(x,P23m,'-.','linewidth',1.5,'Color',[1.0 0.84 0.00])
plot(x,P30m,'-.','linewidth',1.5,'Color',[0.01 0.66 0.62])
plot(x,P42m,'-.','linewidth',1.5,'Color',[0.54 0.17 0.89])
xlim([1 21]);
ylim([-0.5 1.5]);
set(gca,'xTick',1:10:21);
set(gca,'xTicklabel',{'274','279','285'});
set(gca,'xticklabel',[])
ylabel('{\itp} (Pa)')

subplot('position',[0.07,0.39 0.72 0.25])  % Um『274-285』
x     = [1:1:21];
x     = x.';
plot(x,W1m,'-.','linewidth',1.5,'Color',[0.98 0.50 0.45])
hold on
plot(x,U9m,'-.','linewidth',1.5,'Color',[0.25 0.41 0.88])
plot(x,U17m,'-.','linewidth',1.5,'Color',[0.69 0.09 0.12])
plot(x,U23m,'-.','linewidth',1.5,'Color',[1.0 0.84 0.00])
plot(x,U30m,'-.','linewidth',1.5,'Color',[0.01 0.66 0.62])
plot(x,U42m,'-.','linewidth',1.5,'Color',[0.54 0.17 0.89])
xlim([1 21]);
ylim([-0.15e-4 1.8e-4]);
set(gca,'xTick',1:10:21);
set(gca,'xTicklabel',{'274','279','285'});
set(gca,'xticklabel',[])
ylabel('{\itu_m} (m/s)')


subplot('position',[0.07,0.1 0.72 0.25])  % Em『274-285』
x     = [1:1:21];
x     = x.';
plot(x,W1m,'-.','linewidth',1.5,'Color',[0.98 0.50 0.45])
hold on
plot(x,W9m,'-.','linewidth',1.5,'Color',[0.25 0.41 0.88])
plot(x,W17m,'-.','linewidth',1.5,'Color',[0.69 0.09 0.12])
plot(x,W23m,'-.','linewidth',1.5,'Color',[1.0 0.84 0.00])
plot(x,W30m,'-.','linewidth',1.5,'Color',[0.01 0.66 0.62])
plot(x,W42m,'-.','linewidth',1.5,'Color',[0.54 0.17 0.89])
xlim([1 21]);
ylim([-0.2 3.3]);
set(gca,'xTick',1:4:21);
set(gca,'xTicklabel',{'274','276','278','280','282','285'});
xlabel('Time (s)')
ylabel('{\itE_m} (s^-^2)')


subplot('position',[0.84,0.68 0.15 0.25])   % P『284』
x     = [1:1:21];
x     = x.';
plot(x,P1m,'-.','linewidth',2,'Color',[0.98 0.50 0.45])
hold on
plot(x,P9m,'-.','linewidth',2,'Color',[0.25 0.41 0.88])
plot(x,P17m,'-.','linewidth',2,'Color',[0.69 0.09 0.12])
plot(x,P23m,'-.','linewidth',2,'Color',[1.0 0.84 0.00])
plot(x,P30m,'-.','linewidth',2,'Color',[0.01 0.66 0.62])
plot(x,P42m,'-.','linewidth',2,'Color',[0.54 0.17 0.89])
xlim([18.5 19.5]);
ylim([-0.05 0.43]);
set(gca,'xTick',1:10:21);
set(gca,'xTicklabel',{'274','279','285'});
set(gca,'xticklabel',[])
% ylabel('{\itp} (Pa)','FontSize',21)

subplot('position',[0.84,0.39 0.15 0.25])   % Um『284』
x     = [1:1:21];
x     = x.';
plot(x,W1m,'-.','linewidth',2,'Color',[0.98 0.50 0.45])
hold on
plot(x,U9m,'-.','linewidth',2,'Color',[0.25 0.41 0.88])
plot(x,U17m,'-.','linewidth',2,'Color',[0.69 0.09 0.12])
plot(x,U23m,'-.','linewidth',2,'Color',[1.0 0.84 0.00])
plot(x,U30m,'-.','linewidth',2,'Color',[0.01 0.66 0.62])
plot(x,U42m,'-.','linewidth',2,'Color',[0.54 0.17 0.89])
xlim([18.5 19.5]);
ylim([-0.8e-6 7e-6]);
set(gca,'xTick',1:10:21);
set(gca,'xTicklabel',{'274','279','285'});
set(gca,'xticklabel',[])
% ylabel('{\itu_m} (m/s)','FontSize',21)


subplot('position',[0.84,0.1 0.15 0.25])   % Em『284』
x     = [1:1:21];
x     = x.';
plot(x,W1m,'-.','linewidth',2,'Color',[0.98 0.50 0.45])
hold on
plot(x,W9m,'-.','linewidth',2,'Color',[0.25 0.41 0.88])
plot(x,W17m,'-.','linewidth',2,'Color',[0.69 0.09 0.12])
plot(x,W23m,'-.','linewidth',2,'Color',[1.0 0.84 0.00])
plot(x,W30m,'-.','linewidth',2,'Color',[0.01 0.66 0.62])
plot(x,W42m,'-.','linewidth',2,'Color',[0.54 0.17 0.89])
xlim([18.5 19.5]);
ylim([-0.0005 0.0025]);
set(gca,'xTick',1:1:21);
set(gca,'xTicklabel',{'284'});

% ylabel('{\itE_m} (s^-^2)','FontSize',21)






hl = legend('Re-11','Re-105','Re-204 ','Re-275','Re-354','Re-500')
set(hl,'Orientation','horizon','Box','off')
hl.ItemTokenSize = [12,40];



